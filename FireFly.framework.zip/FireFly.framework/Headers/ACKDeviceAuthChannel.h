//
// Created by Jiang Lu on 14-3-31.
// Copyright (c) 2014 Google Inc. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ACKCastChannel.h"

/**
 * 设备认证通道
 */

@protocol ACKDeviceAuthChannelDelegate;

@interface ACKDeviceAuthChannel : ACKCastChannel {
@public
    SecTrustRef *_peerTrust;
//    NSArray *_anchorCertArray; // {__NSCType *} "<cert(0x8c782c0) s: Eureka Gen1 ICA i: Eureka Root CA>"
}

@property(nonatomic) id <ACKDeviceAuthChannelDelegate> delegate;

- (id)init;

- (void)dealloc;

- (BOOL)sendChallengeWithPeerSecTrust:(SecTrustRef *)peerTrust;

- (BOOL)notifyAuthenticationFailure;

- (void)didReceiveBinaryMessage:(NSData *)data;

- (NSString *)description2;

@end

@protocol ACKDeviceAuthChannelDelegate <NSObject>

- (BOOL)deviceAuthChannelDidAuthenticate:(id)deviceAuthChannel;

@end