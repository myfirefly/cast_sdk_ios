//
// Created by Jiang Lu on 14-4-8.
// Copyright (c) 2014 Google inc. All rights reserved.
//

#import <Foundation/Foundation.h>

@class ACKMediaInformation;

/** A flag (bitmask) indicating that a media item can be paused. */
extern const NSInteger kACKMediaCommandPause;

/** A flag (bitmask) indicating that a media item supports seeking. */
extern const NSInteger kACKMediaCommandSeek;

/** A flag (bitmask) indicating that a media item's audio volume can be changed. */
extern const NSInteger kACKMediaCommandSetVolume;

/** A flag (bitmask) indicating that a media item's audio can be muted. */
extern const NSInteger kACKMediaCommandToggleMute;

/** A flag (bitmask) indicating that a media item supports skipping forward. */
extern const NSInteger kACKMediaCommandSkipForward;

/** A flag (bitmask) indicating that a media item supports skipping backward. */
extern const NSInteger kACKMediaCommandSkipBackward;

typedef NS_ENUM(NSInteger, ACKMediaPlayerState) {
    /** Constant indicating unknown player state. */
    ACKMediaPlayerStateUnknown = 0,
    /** Constant indicating that the media player is idle. */
    ACKMediaPlayerStateIdle = 1,
    /** Constant indicating that the media player is playing. */
    ACKMediaPlayerStatePlaying = 2,
    /** Constant indicating that the media player is paused. */
    ACKMediaPlayerStatePaused = 3,
    /** Constant indicating that the media player is buffering. */
    ACKMediaPlayerStateBuffering = 4,
};

typedef NS_ENUM(NSInteger, ACKMediaPlayerIdleReason) {
    /** Constant indicating that the player currently has no idle reason. */
    ACKMediaPlayerIdleReasonNone = 0,
    
    /** Constant indicating that the player is idle because playback has finished. */
    ACKMediaPlayerIdleReasonFinished = 1,
    
    /**
     * Constant indicating that the player is idle because playback has been cancelled in
     * response to a STOP command.
     */
    ACKMediaPlayerIdleReasonCancelled = 2,
    
    /**
     * Constant indicating that the player is idle because playback has been interrupted by
     * a LOAD command.
     */
    ACKMediaPlayerIdleReasonInterrupted = 3,
    
    /** Constant indicating that the player is idle because a playback error has occurred. */
    ACKMediaPlayerIdleReasonError = 4,
};

/**
 * A class that holds status information about some media.
 */
@interface ACKMediaStatus : NSObject

/**
 * The media session ID for this item.
 */
@property(nonatomic) NSInteger mediaSessionID;

/**
 * The current player state.
 */
@property(nonatomic) ACKMediaPlayerState playerState;

/**
 * The current idle reason. This value is only meaningful if the player state is
 * ACKMediaPlayerStateIdle.
 */
@property(nonatomic) ACKMediaPlayerIdleReason idleReason;

/**
 * Gets the current stream playback rate. This will be negative if the stream is seeking
 * backwards, 0 if the stream is paused, 1 if the stream is playing normally, and some other
 * postive value if the stream is seeking forwards.
 */
@property(nonatomic) float playbackRate;

/**
 * The ACKMediaInformation for this item.
 */
@property(nonatomic, strong) ACKMediaInformation *mediaInformation;

/**
 * The current stream position, as an NSTimeInterval from the start of the stream.
 */
@property(nonatomic) NSTimeInterval streamPosition;

/**
 * The stream's volume.
 */
@property(nonatomic) float volume;

/**
 * The stream's mute state.
 */
@property(nonatomic) BOOL isMuted;

/**
 * Any custom data that is associated with the media item.
 */
@property(nonatomic, strong) id customData;

/**
 * Designated initializer.
 *
 * @param mediaSessionID The media session ID.
 * @param mediaInformation The media information.
 */
- (id)initWithSessionID:(NSInteger)mediaSessionID
       mediaInformation:(ACKMediaInformation *)mediaInformation;

/**
 * Checks if the stream supports a given control command.
 */
- (BOOL)isMediaCommandSupported:(NSInteger)command;


- (id)initWithJSONObject:(id)jsonObject;////////////////

-(NSInteger)updateFromJSONObject:(id) jsonObject;


@end