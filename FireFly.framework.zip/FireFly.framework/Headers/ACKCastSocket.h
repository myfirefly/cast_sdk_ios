//
// Created by Jiang Lu on 14-4-8.
// Copyright (c) 2014 Google inc. All rights reserved.
//

#import <Foundation/Foundation.h>

@class GCDAsyncSocket;

@protocol ACKCastSocketDelegate;

@interface ACKCastSocket : NSObject {
//@public
//    BOOL _writesPending;
//    NSMutableData *_incomingHeader;
//    NSInteger _state;
//    GCDAsyncSocket *_asyncSocket;
//    
@public
    GCDAsyncSocket *_asyncSocket; // nil
    NSMutableData *_incomingMessage; // nil
    NSMutableData *_incomingHeader; // nil
    NSUInteger _state; // 0
    NSUInteger _writesPending; // 0
    NSTimer *_connectTimer; // nil
    NSTimer *_drainTimer; // nil
    BOOL _shouldDisconnect; // NO
    BOOL _readHeaderPending; // NO
    // id _delegate; // nil
    NSUInteger _writeBufferAvailableBytes; // 0
    NSUInteger _writeBufferPendingBytes; // 0
    NSUInteger _maxMessageLength; // 0
}

@property(nonatomic, weak) id <ACKCastSocketDelegate> delegate;

- (BOOL)connectToHost:(NSString *)ipAddress port:(UInt32)port;

- (void)writeMessageLength:(NSUInteger)length toData:(NSMutableData *)data;

- (BOOL)sendMessage:(NSData *)data;

- (void)doTeardownWithError:(id)error;

- (void)disconnect;

- (void)connectTimerDidFire;

- (void)socket:(GCDAsyncSocket *)sock didConnectToHost:(NSString *)host port:(uint16_t)port;

- (void)socket:(GCDAsyncSocket *)sock didReadData:(NSData *)data withTag:(long)tag;

- (void)socket:(GCDAsyncSocket *)sock didWriteDataWithTag:(long)tag;

@end

/**
 * The delegate for ACKCastSocket notifications.
 */
@protocol ACKCastSocketDelegate <NSObject>

/**
 * 与 Device 的 TLS 连接已经建立
 */
- (void)castSocket:(ACKCastSocket *)socket didConnectWithPeerSecTrust:(SecTrustRef *)peerTrust;

- (void)castSocket:(ACKCastSocket *)socket didDisconnectWithError:(NSError *)error;

- (void)castSocket:(ACKCastSocket *)socket didReceiveMessage:(NSData *)message;

@end