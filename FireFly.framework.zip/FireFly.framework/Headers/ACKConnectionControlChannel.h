//
// Created by Jiang Lu on 14-3-31.
// Copyright (c) 2014 Google Inc. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ACKCastChannel.h"
/**
 * 连接控制通道
 */
@interface ACKConnectionControlChannel : ACKCastChannel {
@public
    NSString *_clientPackageName;
}

- (id)initWithNamespace:(NSString *)protocolNamespace;

- (id)initWithClientPackageName:(NSString *)clientPackageName;

- (BOOL)connectToDestinationID:(NSString *)destinationID;

- (BOOL)disconnectFromDestinationID:(NSString *)destinationID;

- (NSString *)buildUserAgentString;

@end