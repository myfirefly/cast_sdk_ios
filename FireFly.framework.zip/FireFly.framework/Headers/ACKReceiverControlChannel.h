//
// Created by Jiang Lu on 14-3-31.
// Copyright (c) 2014 Google Inc. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ACKApplicationMetadata.h"
#import "ACKCastChannel.h"

@protocol ACKReceiverControlChannelDelegate;
/**
 * Receiver 控制通道
 */
@interface ACKReceiverControlChannel : ACKCastChannel {
}


@property(nonatomic, weak) id <ACKReceiverControlChannelDelegate> delegate;

- (id)initWithNamespace:(NSString *)protocolNamespace;

/**
 * Designated initializer.
 * @param receiverDestinationID The destination ID for the receiver.
 */
- (id)initWithReceiverDestinationID:(NSString *)receiverDestinationID;

/**
 * Channel disconnect
 */
- (BOOL)didDisconnect;

/**
 * True if currently launching an application.
 */
- (BOOL)isLaunchingApplication;

/**
 * Launches an application, with given command paraments, optionally relaunching it if it is
 * already running.
 *
 * @param applicationID The application ID.
 * @return The request ID, or kACKInvalidRequestID if the message could not be sent.
 */
- (NSInteger)launchApplication:(NSString *)applicationID;

/**
 * 应用启动超时
 */
- (BOOL)launchTimeoutTimerDidFire;

/**
 * Stops any running application(s).
 *
 * @return The request ID, or kACKInvalidRequestID if the message could not be sent.
 */
- (NSInteger)stopApplication;

/**
 * Stops the application with the given session ID. Session ID must be non-negative.
 *
 * @param sessionId The session ID.
 * @return The request ID, or kACKInvalidRequestID if the message could not be sent.
 */
- (NSInteger)stopApplicationWithSessionID:(NSString *)sessionID;

/**
 * Requests the device's current status.
 *
 * @return The request ID, or kACKInvalidRequestID if the message could not be sent.
 */
- (NSInteger)requestDeviceStatus;

/**
 * Requests the availability for a list of app IDs.
 *
 * @return The request ID, or kACKInvalidRequestID if the message could not be sent.
 */
- (NSInteger)requestAvailabilityForAppIDs:(NSArray *)appIDs;

/**
 * Sets the system volume.
 *
 * @param volume The new volume, in the range [0.0, 1.0]. Out of range values will be silently
 * clipped.
 * @return The request ID, or kACKInvalidRequestID if the message could not be sent.
 */
- (NSInteger)setVolume:(float)volume;

/**
 * Turns muting on or off.
 *
 * @param muted Whether audio should be muted or unmuted.
 * @return The request ID, or kACKInvalidRequestID if the message could not be sent.
 */
- (NSInteger)setMuted:(BOOL)muted;

- (BOOL)launchTimeoutTimerDidFire;

- (BOOL)volumeLevelRequestTimeoutTimerDidFire;

- (BOOL)muteRequestTimeoutTimerDidFire;

- (void)didReceiveTextMessage:(NSString *)message;

- (BOOL)notifyDidFailToLaunchAppWithError:(NSError *)error;

- (BOOL)notifyRequestDidFailWithID :(NSInteger)failId error:(NSError *)error;

@end

@protocol ACKReceiverControlChannelDelegate <NSObject>

/**
 * Called when an application has been launched.
 *
 * @param applicationMetadata Metadata about the application.
 */
- (void)receiverControlChannel:(ACKReceiverControlChannel *)receiverControlChannel
      didLaunchCastApplication:(ACKApplicationMetadata *)applicationMetadata;

/**
 * Called when an application launch fails.
 *
 * @param error The error that identifies the reason for the failure.
 */
- (void)         receiverControlChannel:(ACKReceiverControlChannel *)receiverControlChannel
didFailToLaunchCastApplicationWithError:(NSError *)error;

/**
 * Called when a request fails.
 *
 * @param requestID The request ID that failed.
 * @param error The error that identifies the reason for the failure.
 */
- (void)receiverControlChannel:(ACKReceiverControlChannel *)receiverControlChannel
          requestDidFailWithID:(NSInteger)requestID
                         error:(NSError *)error;

/**
 * Called whenever updated status information is received.
 *
 * @param applicationMetadata The application metadata.
 */
- (void)receiverControlChannel:(ACKReceiverControlChannel *)receiverControlChannel
didReceiveStatusForApplication:(ACKApplicationMetadata *)applicationMetadata;

/**
 * Called whenever the volume changes.
 *
 * @param volumeLevel The current device volume level.
 * @param isMuted The current device mute state.
 */
- (void)receiverControlChannel:(ACKReceiverControlChannel *)receiverControlChannel
        volumeDidChangeToLevel:(float)volumeLevel
                       isMuted:(BOOL)isMuted;

/**
 * Called whenever app availability information is received.
 *
 * @param appAvailability A dictionary from app ID (as an NSString) to app availability (as an
 * NSNumber containing a ACKAppAvailability value).
 */
- (void)receiverControlChannel:(ACKReceiverControlChannel *)receiverControlChannel
     didReceiveAppAvailability:(NSDictionary *)appAvailability;

@end
