//
// Created by Jiang Lu on 14-4-8.
// Copyright (c) 2014 Google inc. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol ACKDeviceFilterListener;
@class ACKDevice;
@class ACKDeviceScanner;
@class ACKFilterCriteria;
@class ACKDeviceFilterDeviceScannerWeakListener;
/**
 * Filters device scanner results to return only those devices which support or are running
 * applications which meet some given critera.
 */
@interface ACKDeviceFilter : NSObject

@property(nonatomic, copy) NSArray *devices;

- (id)initWithDeviceScanner:(ACKDeviceScanner *)scanner criteria:(ACKFilterCriteria *)criteria;

- (void)addDeviceFilterListener:(id<ACKDeviceFilterListener>)listener;
- (void)removeDeviceFilterListener:(id<ACKDeviceFilterListener>)listener;

@end

@protocol ACKDeviceFilterListener <NSObject>

/**
 * Called when a supported device has come online.
 *
 * @param device The device.
 */
- (void)deviceDidComeOnline:(ACKDevice *)device
            forDeviceFilter:(ACKDeviceFilter *)deviceFilter;

/**
 * Called when a supported device has gone offline.
 *
 * @param device The device.
 */
- (void)deviceDidGoOffline:(ACKDevice *)device
           forDeviceFilter:(ACKDeviceFilter *)deviceFilter;

@end

