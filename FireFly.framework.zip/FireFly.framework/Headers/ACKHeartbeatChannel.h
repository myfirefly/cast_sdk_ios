//
// Created by Jiang Lu on 14-3-31.
// Copyright (c) 2014 Google Inc. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ACKCastChannel.h"

@protocol ACKHeartbeatChannelDelegate;
/**
 * 心跳检测通道
 */
@interface ACKHeartbeatChannel : ACKCastChannel {
@public
    NSTimer *_heartbeatTimer; // PING/PONG 发送定时器
    NSTimer *_inactivityTimer; // 超时定时器
    NSTimeInterval _heartbeatInterval; // PING/PONG 发送间隔
    NSTimeInterval _inactivityTimeout; // 超时时间
}

@property(nonatomic) id <ACKHeartbeatChannelDelegate> delegate;

- (id)init;

/**
 * 开始心跳检测，并设定最大超时时间
 */
- (BOOL)startHeartbeatWithInactivityTimeout:(NSTimeInterval)maxInactivityInterval;

/**
 * 重置心跳检测定时器
 */
- (BOOL)resetHeartbeat;

/**
 * 停止心跳检测
 */
- (BOOL)stopHeartbeat;

- (BOOL)didDisconnect;

- (BOOL)didReceiveTextMessage:(NSString *)message;

- (BOOL)sendPong;

- (BOOL)sendPing;

- (BOOL)heartbeatTimerDidFire;

- (BOOL)inactivityTimerDidFire;

- (BOOL)scheduleTimers;

@end

@protocol ACKHeartbeatChannelDelegate <NSObject>

- (BOOL)heartbeatChannelDidTimeout:(id)heartbeatChannel;

@end