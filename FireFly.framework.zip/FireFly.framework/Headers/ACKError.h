//
// Created by Jiang Lu on 14-4-8.
// Copyright (c) 2014 Google inc. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSInteger, ACKErrorCode) {
    
    /**
     * Error code indicating a network I/O error.
     */
    ACKErrorCodeNetworkError = 1,
    
    /**
     * Error code indicating that an operation has timed out.
     */
    ACKErrorCodeTimeout = 2,
    
    /**
     * Error code indicating an authentication error.
     */
    ACKErrorCodeDeviceAuthenticationFailure = 3,
    
    /**
     * Error code indicating that an invalid request was made.
     */
    ACKErrorCodeInvalidRequest = 4,
    
    /**
     * Error code indicating that an in-progress request has been cancelled, most likely because
     * another action has preempted it.
     */
    ACKErrorCodeCancelled = 5,
    
    /**
     * Error code indicating that the request was disallowed and could not be completed.
     */
    ACKErrorCodeNotAllowed = 6,
    
    /**
     * Error code indicating that a requested application could not be found.
     */
    ACKErrorCodeApplicationNotFound = 7,
    
    /**
     * Error code indicating that a requested application is not currently running.
     */
    ACKErrorCodeApplicationNotRunning = 8,
    
    /**
     * Error code indicating the app entered the background.
     */
    ACKErrorCodeAppDidEnterBackground = 91,
    
    /**
     * Error code indicating a disconnection occurred during the request.
     */
    ACKErrorCodeDisconnected = 92,
    
    /**
     * Error code indicating that a request could not be made because the same type of request is
     * still in process.
     */
    ACKErrorCodeDuplicateRequest = 93,
    
    /**
     * Error code indicating that a media load failed on the receiver side.
     */
    ACKErrorCodeMediaLoadFailed = 94,
    
    /**
     * Error code indicating that a media media command failed because of the media player state.
     */
    ACKErrorCodeInvalidMediaPlayerState = 95,
    
    /**
     * Error code indicating that an unknown, unexpected error has occurred.
     */
    ACKErrorCodeUnknown = 99,
};

/**
 * The key for the customData JSON object associated with the error in the userInfo dictionary.
 */
extern NSString *const kACKErrorCustomDataKey;

/**
 * The class for all ACK framework errors.
 *
 * @ingroup Utilities
 */
@interface ACKError : NSError

/**
 * Returns the name of the enum value for a given error code.
 */
+ (NSString *)enumDescriptionForCode:(ACKErrorCode)code;

/** @cond INTERNAL */

/**
 * Designated initializer.
 */
- (id)initWithCode:(ACKErrorCode)code additionalUserInfo:(NSDictionary *)additionalUserInfo;

- (id)initWithCode:(ACKErrorCode)code;

/** @endcond */

@end